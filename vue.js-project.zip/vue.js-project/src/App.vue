<script>
export default {
  data() {
    return {
      newUser: { name: '', email: '' }, // Stores user input
      users: [], // Stores the list of users
      isNameFocused: false,
      isEmailFocused: false
    };
  },
  methods: {
    // Add user if both name and email are provided
    addUser() {
      if (this.newUser.name && this.newUser.email) {
        this.users.push({ ...this.newUser });
        this.newUser.name = '';
        this.newUser.email = '';
      }
    },
    // Edit a user by prefilling the form
    editUser(index) {
      this.newUser = { ...this.users[index] };
      this.users.splice(index, 1);
    },
    // Remove a user from the list with a fade-out effect
    deleteUser(index) {
      this.users.splice(index, 1);
    }
  }
};
</script>

<template>
  <div class="wrapper">
    <!-- User Form -->
    <div class="container">
      <h2 class="text-center title">👥 User Management</h2>

      <form @submit.prevent="addUser" class="form-container">
        <div class="input-group">
          <input 
            v-model="newUser.name" 
            class="form-control" 
            @focus="isNameFocused = true" 
            @blur="isNameFocused = !!newUser.name"
            required
          />
          <label :class="{ 'float': isNameFocused || newUser.name }">Enter Name</label>
        </div>

        <div class="input-group">
          <input 
            v-model="newUser.email" 
            class="form-control" 
            @focus="isEmailFocused = true" 
            @blur="isEmailFocused = !!newUser.email"
            required
          />
          <label :class="{ 'float': isEmailFocused || newUser.email }">Enter Email</label>
        </div>

        <button type="submit" class="btn add-btn">➕ Add</button>
      </form>
    </div>

    <!-- User List -->
    <div class="container user-container" v-if="users.length">
      <h3 class="text-center list-title">📋 User List</h3>
      <div class="user-scrollable">
        <transition-group name="fade" tag="div">
          <div class="user-card" v-for="(user, index) in users" :key="index">
            <div class="user-info">
              <h5>{{ user.name }}</h5>
              <p>{{ user.email }}</p>
            </div>
            <div class="user-actions">
              <button class="btn edit-btn" @click="editUser(index)">✏️ Edit</button>
              <button class="btn delete-btn" @click="deleteUser(index)">🗑️ Delete</button>
            </div>
          </div>
        </transition-group>
      </div>
    </div>

    <p v-else class="no-users">No users added yet. Start by adding one!</p>
  </div>
</template>

<style scoped>
/* General Styles */
body {
  font-family: 'Poppins', sans-serif;
  background-color: #f0f4f8;
}

/* Wrapper to center the layout */
.wrapper {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 20px;
}

/* Containers (Form & User List) */
.container {
  width: 500px;
  background: #e3f2fd;
  padding: 30px; /* Increased padding for better spacing */
  border-radius: 15px;
  box-shadow: 0px 10px 25px rgba(0, 0, 0, 0.12);
}

/* Titles */
.title, .list-title {
  text-align: center;
  font-weight: 600;
  color: #333;
  margin-bottom: 20px;
}

/* Form Styles */
.form-container {
  display: flex;
  flex-direction: column;
  gap: 18px;
  align-items: center;
}

/* Input Groups */
.input-group {
  position: relative;
  width: 100%;
}

/* Textbox Styling */
input {
  width: 100%;
  padding: 14px;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 14px;
  background: white;
  color: black;
  transition: 0.3s ease;
}

input:focus {
  border-color: #007bff;
  outline: none;
  box-shadow: 0px 0px 6px rgba(0, 123, 255, 0.3);
}

/* Labels (Sliding Effect) */
label {
  position: absolute;
  left: 14px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 14px;
  color: black;
  transition: all 0.3s ease;
  pointer-events: none;
}

/* Floating effect when input is focused */
label.float {
  top: -8px;
  font-size: 12px;
  color: #007bff;
}

/* Add Button */
.add-btn {
  background: #007bff;
  color: white;
  font-size: 15px;
  padding: 10px 20px;
  border-radius: 8px;
  transition: 0.3s;
  box-shadow: 0px 5px 10px rgba(0, 123, 255, 0.2);
}

.add-btn:hover {
  background: #0056b3;
  transform: scale(1.05);
}

/* User List */
.user-container {
  background: #e3f2fd;
}

/* Scrollable User List */
.user-scrollable {
  max-height: 220px;
  overflow-y: auto;
  padding-right: 5px;
}

/* Scrollbar Styling */
.user-scrollable::-webkit-scrollbar {
  width: 6px;
}

.user-scrollable::-webkit-scrollbar-track {
  background: #e3f2fd;
  border-radius: 5px;
}

.user-scrollable::-webkit-scrollbar-thumb {
  background: #007bff;
  border-radius: 10px;
}

.user-scrollable::-webkit-scrollbar-thumb:hover {
  background: #0056b3;
}

/* User Cards */
.user-card {
  background: white;
  padding: 18px;
  border-radius: 10px;
  box-shadow: 0px 5px 20px rgba(0, 0, 0, 0.1);
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
  transition: all 0.3s ease;
}

.user-card:hover {
  transform: translateY(-4px);
}

/* Fade Animation */
.fade-enter-active, .fade-leave-active {
  transition: opacity 0.3s ease;
}
.fade-enter, .fade-leave-to {
  opacity: 0;
}

/* User Info */
.user-info h5 {
  margin: 0;
  font-size: 16px;
  font-weight: 600;
}

.user-info p {
  margin: 2px 0 0;
  font-size: 14px;
  color: #666;
}

/* Action Buttons */
.user-actions {
  display: flex;
  gap: 6px;
}

.edit-btn, .delete-btn {
  font-size: 13px;
  padding: 7px 12px;
}

.edit-btn {
  background: #ffc107;
}

.delete-btn {
  background: #dc3545;
  color: white;
}

/* No Users Message */
.no-users {
  text-align: center;
  color: #777;
  font-size: 14px;
  margin-top: 20px;
}
</style>